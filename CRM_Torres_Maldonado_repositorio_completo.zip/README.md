# CRM Torres Maldonado

Aplicación web instalable con dos módulos: captura de contactos inmobiliarios y CRM.

## Lector de capturas

Abre `index.html`, elige una captura de WhatsApp, Messenger o Marketplace, una foto de libreta u otra imagen con datos de un prospecto y pulsa **Leer texto**. El lector muestra texto editable; no extrae productos, no pide cantidades o precios y no calcula totales. Revisa el resultado, selecciona su origen y pulsa **Enviar al CRM**. El CRM abre la captura de contacto con el texto recibido para que confirmes los datos antes de guardarlos.

El reconocimiento OCR en español se ejecuta en el navegador con Tesseract.js. La primera lectura requiere conexión para cargar el motor y el modelo de idioma. La imagen se reconoce en el dispositivo y no se envía a Supabase. Solo el texto confirmado por ti pasa al formulario del CRM.

## CRM

Abre `crm.html` para registrar compradores, propietarios, personas que buscan u ofrecen renta y aportantes/inversionistas. El CRM usa Supabase Auth y RLS para sincronizar los contactos entre dispositivos; conserva una copia local. El puente del lector pasa el texto al formulario del CRM en el mismo navegador; no envía tickets ni importes a ninguna tabla.

Proyecto GitHub Pages: `https://crmarketinmobiliario-del.github.io/CRM-MARKETINMOBILIARIO/`

En Supabase, **Authentication → URL Configuration**:

- Site URL: `https://crmarketinmobiliario-del.github.io/CRM-MARKETINMOBILIARIO/`
- Redirect URL: `https://crmarketinmobiliario-del.github.io/CRM-MARKETINMOBILIARIO/crm.html`

El correo y la contraseña del CRM son propios de Supabase Auth; no son los de Google. La carpeta `supabase/` contiene el esquema de base de datos.

## Instalación

Abre el sitio HTTPS. En Chrome o Edge usa **Instalar app**; en iPhone/iPad, abre el sitio en Safari y selecciona **Añadir a pantalla de inicio**.
